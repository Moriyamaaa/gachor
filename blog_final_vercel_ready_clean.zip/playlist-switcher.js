// TODO: Spotify playlist switcher based on mood or day
