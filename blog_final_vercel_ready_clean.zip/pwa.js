// TODO: Service Worker and manifest setup for PWA
