
// Ganti ini dengan nilai dari akun EmailJS kamu
/**emailjs.init("YOUR_PUBLIC_KEY");
const SERVICE_ID = "YOUR_SERVICE_ID";
const TEMPLATE_ID = "YOUR_TEMPLATE_ID";
*/
// Inisialisasi EmailJS dengan Public Key dummy
emailjs.init("public_test_dummy123");

const SERVICE_ID = "service_test123";
const TEMPLATE_ID = "template_test123";