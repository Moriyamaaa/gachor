// TODO: Particle background animation setup
