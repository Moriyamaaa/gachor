// TODO: Portfolio grid renderer
