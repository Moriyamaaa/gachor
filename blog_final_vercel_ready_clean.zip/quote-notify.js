// TODO: Notification API for daily quote
