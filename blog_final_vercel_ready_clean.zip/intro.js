// TODO: Add animated entry page (intro animation)
